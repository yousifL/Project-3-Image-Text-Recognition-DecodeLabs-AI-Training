"""
Project 4 - Path 1: Optical Character Recognition (OCR)
DecodeLabs AI Industrial Training Kit | Batch 2026

Pipeline:
  1. Load image
  2. Grayscale conversion
  3. Gaussian blur
  4. Adaptive thresholding (Otsu's method)
  5. Tesseract OCR with PSM tuning
  6. Display results with confidence scores
"""

import cv2
import numpy as np
import pytesseract
from PIL import Image
import os
import sys


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
CONFIDENCE_THRESHOLD = 0.80   # 80% minimum — The Gatekeeper Rule
PSM_MODE = 6                   # 6 = single uniform text block (change to 3 for auto, 11 for sparse/invoices)

# On Windows you may need: pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'


# ─────────────────────────────────────────────
# STEP 1: Load Image
# ─────────────────────────────────────────────
def load_image(image_path: str) -> np.ndarray:
    """Load image from disk and validate it."""
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Could not read image: {image_path}")
    print(f"[✓] Loaded image: {image_path}  |  Shape: {img.shape}")
    return img


# ─────────────────────────────────────────────
# STEP 2-4: Pre-Processing Pipeline
# ─────────────────────────────────────────────
def preprocess(img: np.ndarray) -> np.ndarray:
    """
    Convert the 3D RGB matrix → 1D intensity matrix → binary.
    Removes color noise, smooths micro-imperfections, maximises contrast.
    """
    # Step 2: Grayscale — collapses 3 channels into 1 intensity channel
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    print(f"[✓] Grayscale conversion done  |  Shape: {gray.shape}")

    # Step 3: Gaussian Blur — smooths artifact noise before thresholding
    blurred = cv2.GaussianBlur(gray, (3, 3), 0)
    print("[✓] Gaussian blur applied")

    # Step 4: Adaptive Thresholding (Otsu's method)
    # Forces every pixel to choose: 0 (black) or 255 (white)
    _, binary = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    print(f"[✓] Otsu adaptive thresholding applied")

    return binary


# ─────────────────────────────────────────────
# STEP 5: OCR Extraction
# ─────────────────────────────────────────────
def run_ocr(binary_img: np.ndarray, psm: int = PSM_MODE) -> dict:
    """
    Run Tesseract OCR engine on the pre-processed binary image.
    Returns full data dict including per-word confidence scores.
    """
    config = f"--oem 3 --psm {psm}"
    pil_img = Image.fromarray(binary_img)

    # Get detailed data including confidence per word
    data = pytesseract.image_to_data(pil_img, config=config, output_type=pytesseract.Output.DICT)
    # Also get the clean text string
    raw_text = pytesseract.image_to_string(pil_img, config=config)
    print(f"[✓] OCR extraction complete")
    return data, raw_text.strip()


# ─────────────────────────────────────────────
# STEP 6: Filter by Confidence & Display
# ─────────────────────────────────────────────
def display_results(original_img: np.ndarray, data: dict, raw_text: str,
                    threshold: float = CONFIDENCE_THRESHOLD) -> np.ndarray:
    """
    Filter OCR words by confidence >= threshold.
    Draw bounding boxes around high-confidence words on the original image.
    """
    output = original_img.copy()
    valid_words = []
    confidences = []

    n_boxes = len(data["text"])
    for i in range(n_boxes):
        word = data["text"][i].strip()
        conf = int(data["conf"][i])

        if word and conf != -1:
            conf_ratio = conf / 100.0
            confidences.append(conf_ratio)

            if conf_ratio >= threshold:
                valid_words.append(word)
                # Draw bounding box
                x, y, w, h = data["left"][i], data["top"][i], data["width"][i], data["height"][i]
                cv2.rectangle(output, (x, y), (x + w, y + h), (0, 200, 0), 2)
                label = f"{word} ({conf}%)"
                cv2.putText(output, label, (x, y - 6),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 200, 0), 1)

    # ── Summary ──────────────────────────────
    avg_conf = (sum(confidences) / len(confidences)) if confidences else 0
    print("\n" + "═" * 55)
    print("  OCR RESULTS — PROJECT 4 OUTPUT")
    print("═" * 55)
    print(f"  Full extracted text:\n\n{raw_text}\n")
    print(f"  High-confidence words (≥{int(threshold*100)}%):")
    print(f"  {' | '.join(valid_words) if valid_words else 'None found'}")
    print(f"\n  Average confidence: {avg_conf*100:.1f}%")

    if avg_conf >= threshold:
        print(f"  ✅ MILESTONE PASSED — Confidence ≥ 80%")
    else:
        print(f"  ❌ Below threshold — Try a cleaner image or adjust PSM mode")
    print("═" * 55)

    return output


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def run_pipeline(image_path: str):
    print("\n🚀 Project 4 | OCR Pipeline Starting...\n")

    img = load_image(image_path)
    binary = preprocess(img)
    data, raw_text = run_ocr(binary)
    output_img = display_results(img, data, raw_text)

    # Save preprocessed and output images
    cv2.imwrite("preprocessed.png", binary)
    cv2.imwrite("ocr_output.png", output_img)
    print("\n[✓] Saved: preprocessed.png | ocr_output.png")

    # Show result (comment out if running headless)
    cv2.imshow("OCR Output", output_img)
    cv2.imshow("Pre-processed (Binary)", binary)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    # Default: use sample.png in the same folder
    # You can pass a custom path as a CLI argument: python ocr_recognition.py my_image.jpg
    image_path = sys.argv[1] if len(sys.argv) > 1 else "sample.png"
    run_pipeline(image_path)
