# 🤖 Project 4 — Image & Text Recognition
### DecodeLabs AI Industrial Training Kit | Batch 2026

> *"Mastering Project 4 means building the bridge between the physical world and computational logic. You are graduating to machine perception."*

---

## 📌 What This Project Does

This project implements **two fully functional AI recognition pipelines** in Python:

| Path | Task | Libraries |
|------|------|-----------|
| **Path 1** | Optical Character Recognition (OCR) | `pytesseract`, `OpenCV`, `Pillow` |
| **Path 2** | Object Detection with bounding boxes | `OpenCV DNN`, `MobileNet-SSD` |

Both pipelines pass the **4 Milestone Validations** required by Project 4:
1. ✅ Library Integration (pytesseract / cv2.dnn)
2. ✅ Pre-Processing Integrity (grayscale → blur → thresholding)
3. ✅ Accuracy Benchmarking (≥ 80% confidence threshold enforced)
4. ✅ Visual Confirmation (annotated output image saved to disk)

---

## 🗂️ Project Structure

```
project4/
├── ocr_recognition.py      # Path 1: OCR pipeline
├── object_detection.py     # Path 2: Object detection pipeline
├── download_models.py      # Helper: downloads MobileNet-SSD weights
├── requirements.txt        # All dependencies
└── README.md               # This file
```

---

## ⚙️ Setup

### 1. Install Python dependencies
```bash
pip install -r requirements.txt
```

### 2. Install Tesseract OCR engine (for Path 1)

**Ubuntu/Debian:**
```bash
sudo apt install tesseract-ocr
```
**macOS:**
```bash
brew install tesseract
```
**Windows:** Download installer from https://github.com/UB-Mannheim/tesseract/wiki

### 3. Download MobileNet-SSD model files (for Path 2)
```bash
python download_models.py
```

---

## 🚀 Running the Pipelines

### Path 1 — OCR
```bash
python ocr_recognition.py your_image.png
```
**Output:** `preprocessed.png` (binary), `ocr_output.png` (annotated with word boxes + confidence %)

**PSM Modes** (edit `PSM_MODE` in the script):
| Mode | Best For |
|------|----------|
| `--psm 3` | Auto layout (default) |
| `--psm 6` | Single block of text / book pages |
| `--psm 7` | Single line (number plates, headers) |
| `--psm 11` | Sparse / scattered text (invoices) |

### Path 2 — Object Detection
```bash
python object_detection.py your_image.jpg
```
**Output:** `detection_output.png` — bounding boxes drawn with `(X, Y, W, H)` and confidence labels

---

## 🧠 How It Works

### OCR Pipeline
```
Raw Image
   │
   ▼
Grayscale (RGB → Intensity matrix)
   │
   ▼
Gaussian Blur (removes noise)
   │
   ▼
Otsu Adaptive Thresholding (binary: black/white)
   │
   ▼
Tesseract OCR (LSTM neural engine)
   │
   ▼
Confidence Filter (≥ 80%) → Annotated Output
```

### Object Detection Pipeline
```
Raw Image
   │
   ▼
blobFromImage (resize 300x300, mean subtraction)
   │
   ▼
MobileNet-SSD Forward Pass (Single Shot Detector)
   │
   ▼
Normalised Coordinates → Pixel (X, Y, W, H)
   │
   ▼
Confidence Filter (≥ 80%) → Bounding Box Overlay
```

---

## 📦 Requirements

```
opencv-python
pytesseract
Pillow
numpy
```

---

## 🔑 Key Concepts

- **Transfer Learning** — MobileNet was pre-trained on ImageNet (millions of images). We reuse its learned visual features without retraining.
- **Blob Construction** — Converts image to 4D tensor `(N, C, H, W)` normalised for the DNN.
- **Softmax & Confidence** — The model outputs probabilities; the 80% gate filters false positives.
- **Adaptive Thresholding** — Otsu's method calculates the optimal pixel cutoff per image automatically.

---

## 🏆 Milestone Validation Checklist

- [x] Script runs without errors
- [x] Pre-processing steps are visible (intermediate images saved)
- [x] Output shows detected text OR labelled bounding boxes
- [x] All detections displayed have ≥ 80% confidence

---

## 📄 License
Built as part of the DecodeLabs AI Industrial Training Program, Batch 2026.
