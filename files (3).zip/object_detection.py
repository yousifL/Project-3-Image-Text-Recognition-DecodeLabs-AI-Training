"""
Project 4 - Path 2: Object Detection with MobileNet-SSD
DecodeLabs AI Industrial Training Kit | Batch 2026

Pipeline:
  1. Load image
  2. Blob construction (4D tensor for DNN)
  3. Forward pass through MobileNet-SSD
  4. Filter detections by 80% confidence threshold
  5. Draw bounding boxes with (X, Y, W, H) coordinates
  6. Display results

NOTE: Download model files before running:
  wget https://raw.githubusercontent.com/chuanqi305/MobileNet-SSD/master/deploy.prototxt -O MobileNetSSD_deploy.prototxt
  wget https://drive.google.com/uc?id=0B3gersZ2cHIxRm5PMWRoTkdHdHc -O MobileNetSSD_deploy.caffemodel
  Or use the download_models.py helper script.
"""

import cv2
import numpy as np
import os
import sys


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
CONFIDENCE_THRESHOLD = 0.80    # 80% — The Gatekeeper Rule (Project 4 minimum)
MODEL_PROTO  = "MobileNetSSD_deploy.prototxt"
MODEL_WEIGHTS = "MobileNetSSD_deploy.caffemodel"

# MobileNet-SSD COCO class labels (21 classes)
CLASSES = [
    "background", "aeroplane", "bicycle", "bird", "boat",
    "bottle", "bus", "car", "cat", "chair",
    "cow", "diningtable", "dog", "horse", "motorbike",
    "person", "pottedplant", "sheep", "sofa", "train", "tvmonitor"
]

# Assign a unique color per class for clarity
np.random.seed(42)
COLORS = np.random.uniform(0, 255, size=(len(CLASSES), 3))


# ─────────────────────────────────────────────
# STEP 1: Load Model
# ─────────────────────────────────────────────
def load_model(proto: str, weights: str) -> cv2.dnn_Net:
    """Load the pre-trained MobileNet-SSD model via OpenCV DNN."""
    if not os.path.exists(proto) or not os.path.exists(weights):
        print("❌ Model files not found. Run download_models.py first.")
        print(f"   Expected: {proto}  |  {weights}")
        sys.exit(1)

    net = cv2.dnn.readNetFromCaffe(proto, weights)
    print(f"[✓] MobileNet-SSD model loaded")
    return net


# ─────────────────────────────────────────────
# STEP 2: Load Image
# ─────────────────────────────────────────────
def load_image(image_path: str):
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError(f"Could not read image: {image_path}")
    print(f"[✓] Loaded image: {image_path}  |  Shape: {img.shape}")
    return img


# ─────────────────────────────────────────────
# STEP 3: Blob Construction (Pre-Processing)
# ─────────────────────────────────────────────
def build_blob(img: np.ndarray) -> np.ndarray:
    """
    Convert the image into a 4D blob tensor for the DNN.
    - Resizes to 300x300 (MobileNet-SSD input requirement)
    - Applies mean subtraction (127.5) to normalise pixel values
    - Scales pixel range to [-1, 1]
    """
    blob = cv2.dnn.blobFromImage(
        cv2.resize(img, (300, 300)),
        scalefactor=0.007843,     # 1/127.5
        size=(300, 300),
        mean=(127.5, 127.5, 127.5)
    )
    print(f"[✓] Blob constructed  |  Shape: {blob.shape}  (4D: N, C, H, W)")
    return blob


# ─────────────────────────────────────────────
# STEP 4: Forward Pass
# ─────────────────────────────────────────────
def detect_objects(net: cv2.dnn_Net, blob: np.ndarray) -> np.ndarray:
    """Run the Single Shot Detector forward pass."""
    net.setInput(blob)
    detections = net.forward()
    print(f"[✓] Forward pass complete  |  Raw detections: {detections.shape[2]}")
    return detections


# ─────────────────────────────────────────────
# STEP 5: Filter & Draw Bounding Boxes
# ─────────────────────────────────────────────
def draw_detections(img: np.ndarray, detections: np.ndarray,
                    threshold: float = CONFIDENCE_THRESHOLD) -> np.ndarray:
    """
    Filter detections by confidence >= threshold.
    Translate normalised coordinates → pixel (X, Y, W, H) bounding boxes.
    """
    output = img.copy()
    h, w = img.shape[:2]

    found = []

    for i in range(detections.shape[2]):
        confidence = float(detections[0, 0, i, 2])

        if confidence >= threshold:
            idx = int(detections[0, 0, i, 1])       # class index
            label = CLASSES[idx] if idx < len(CLASSES) else "unknown"

            # ── Coordinate Scaling ─────────────────
            # Normalised [0,1] → actual pixel coordinates
            x1 = int(detections[0, 0, i, 3] * w)
            y1 = int(detections[0, 0, i, 4] * h)
            x2 = int(detections[0, 0, i, 5] * w)
            y2 = int(detections[0, 0, i, 6] * h)

            # (X, Y) origin + Width & Height
            box_x, box_y = x1, y1
            box_w, box_h = x2 - x1, y2 - y1

            color = COLORS[idx].tolist()
            cv2.rectangle(output, (x1, y1), (x2, y2), color, 2)
            text = f"{label}: {confidence*100:.1f}%"
            cv2.putText(output, text, (x1, y1 - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)

            found.append({
                "label": label,
                "confidence": confidence,
                "box": (box_x, box_y, box_w, box_h)
            })

    # ── Summary ──────────────────────────────
    print("\n" + "═" * 55)
    print("  OBJECT DETECTION RESULTS — PROJECT 4 OUTPUT")
    print("═" * 55)
    if found:
        for obj in found:
            bx, by, bw, bh = obj["box"]
            print(f"  [{obj['label'].upper()}]  Confidence: {obj['confidence']*100:.1f}%")
            print(f"    Bounding Box → X:{bx}  Y:{by}  W:{bw}  H:{bh}")
        print(f"\n  ✅ MILESTONE PASSED — {len(found)} object(s) detected ≥ 80% confidence")
    else:
        print("  ❌ No objects detected above 80% threshold.")
        print("     Try a different image or lower the threshold temporarily.")
    print("═" * 55)

    return output


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def run_pipeline(image_path: str):
    print("\n🚀 Project 4 | Object Detection Pipeline Starting...\n")

    net = load_model(MODEL_PROTO, MODEL_WEIGHTS)
    img = load_image(image_path)
    blob = build_blob(img)
    detections = detect_objects(net, blob)
    output_img = draw_detections(img, detections)

    # Save output
    cv2.imwrite("detection_output.png", output_img)
    print("\n[✓] Saved: detection_output.png")

    # Show result (comment out if running headless)
    cv2.imshow("Object Detection Output", output_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


if __name__ == "__main__":
    image_path = sys.argv[1] if len(sys.argv) > 1 else "sample.jpg"
    run_pipeline(image_path)
