"""
download_models.py
Downloads the MobileNet-SSD model files needed for object_detection.py
Run once before using object_detection.py
"""

import urllib.request
import os

FILES = {
    "MobileNetSSD_deploy.prototxt": (
        "https://raw.githubusercontent.com/chuanqi305/MobileNet-SSD/"
        "master/deploy.prototxt"
    ),
    "MobileNetSSD_deploy.caffemodel": (
        "https://github.com/djmv/MobilNet_SSD_opencv/raw/master/"
        "MobileNetSSD_deploy.caffemodel"
    ),
}

def download(name, url):
    if os.path.exists(name):
        print(f"[skip] {name} already exists.")
        return
    print(f"[↓] Downloading {name} ...")
    urllib.request.urlretrieve(url, name)
    print(f"[✓] Saved {name}")

for fname, furl in FILES.items():
    download(fname, furl)

print("\nAll model files ready. Run: python object_detection.py your_image.jpg")
